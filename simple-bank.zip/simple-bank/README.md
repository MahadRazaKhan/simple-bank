# Simple Bank

Node.js + Express + MySQL banking app, split into separate files.

## Project Structure

```
simple-bank/
├── public/
│   ├── index.html      # HTML markup
│   ├── css/
│   │   └── style.css   # All styling
│   └── js/
│       └── app.js      # Frontend JS (fetch calls, DOM logic)
├── config/
│   └── db.js           # MySQL connection pool
├── routes/
│   └── accounts.js     # Express routes (accounts + transactions)
├── server.js            # Main Express server
├── schema.sql            # MySQL table definitions
├── package.json
└── .env.example
```

## Setup

1. Install dependencies:
   ```
   npm install
   ```

2. Create a MySQL database using `schema.sql`:
   ```
   mysql -u root -p < schema.sql
   ```

3. Copy `.env.example` to `.env` and fill in your MySQL credentials:
   ```
   cp .env.example .env
   ```

4. Run the server:
   ```
   npm start
   ```
   or for auto-reload during development:
   ```
   npm run dev
   ```

5. Open `http://localhost:3000` in your browser.

## API Endpoints

- `GET /api/accounts` — list all accounts
- `POST /api/accounts` — create account `{ name }`
- `DELETE /api/accounts/:id` — delete account
- `GET /api/accounts/:id/balance` — get balance
- `GET /api/accounts/:id/transactions` — list transactions
- `POST /api/accounts/:id/transaction` — deposit/withdraw `{ amount }` (positive = deposit, negative = withdraw)
