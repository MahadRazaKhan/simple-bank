// ---------- ACCOUNT & TRANSACTION ROUTES ----------
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

// ========== MIDDLEWARE ==========
function verifyToken(req, res, next) {
    const header = req.headers.authorization;
    if (!header) return res.status(401).json({ message: 'Unauthorized' });
    try {
        const payload = jwt.verify(header, process.env.JWT_SECRET);
        req.userId = payload.userId;
        next();
    } catch (err) {
        return res.status(401).json({ message: 'Invalid or expired token' });
    }
}

// ========== HELPER: Get user's province ==========
async function getUserProvince(userId, metaDB) {
    const [rows] = await metaDB.query('SELECT province FROM users WHERE id = ?', [userId]);
    if (rows.length === 0) return null;
    return rows[0].province;
}

// ==========================================
// GET ACCOUNTS (User-specific)
// ==========================================
router.get('/accounts', verifyToken, async (req, res) => {
    try {
        const metaDB = req.app.get('metaDB');
        const pools = req.app.get('pools');
        
        const province = await getUserProvince(req.userId, metaDB);
        if (!province) return res.status(404).json({ message: 'User not found' });
        
        const pool = pools.get(province);
        const [rows] = await pool.query(
            'SELECT id, name, balance, province, created_at FROM accounts WHERE user_id = ? ORDER BY id',
            [req.userId]
        );
        res.json({ accounts: rows, province });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// ==========================================
// CREATE ACCOUNT
// ==========================================
router.post('/accounts', verifyToken, async (req, res) => {
    const { name } = req.body;
    if (!name || !name.trim()) {
        return res.status(400).json({ message: 'Account name is required' });
    }
    
    try {
        const metaDB = req.app.get('metaDB');
        const pools = req.app.get('pools');
        
        const province = await getUserProvince(req.userId, metaDB);
        if (!province) return res.status(404).json({ message: 'User not found' });
        
        const pool = pools.get(province);
        const [result] = await pool.query(
            'INSERT INTO accounts (user_id, name, balance, province) VALUES (?, ?, ?, ?)',
            [req.userId, name.trim(), 0.00, province]
        );
        
        const [rows] = await pool.query(
            'SELECT id, user_id, name, balance, province, created_at FROM accounts WHERE id = ?',
            [result.insertId]
        );
        res.status(201).json({ account: rows[0] });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// ==========================================
// DELETE ACCOUNT
// ==========================================
router.delete('/accounts/:id', verifyToken, async (req, res) => {
    const { id } = req.params;
    
    try {
        const metaDB = req.app.get('metaDB');
        const pools = req.app.get('pools');
        
        const province = await getUserProvince(req.userId, metaDB);
        if (!province) return res.status(404).json({ message: 'User not found' });
        
        const pool = pools.get(province);
        const [result] = await pool.query(
            'DELETE FROM accounts WHERE id = ? AND user_id = ?',
            [id, req.userId]
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Account not found' });
        }
        res.json({ message: 'Account deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// ==========================================
// GET BALANCE
// ==========================================
router.get('/accounts/:id/balance', verifyToken, async (req, res) => {
    const { id } = req.params;
    
    try {
        const metaDB = req.app.get('metaDB');
        const pools = req.app.get('pools');
        
        const province = await getUserProvince(req.userId, metaDB);
        if (!province) return res.status(404).json({ message: 'User not found' });
        
        const pool = pools.get(province);
        const [rows] = await pool.query(
            'SELECT balance FROM accounts WHERE id = ? AND user_id = ?',
            [id, req.userId]
        );
        
        if (rows.length === 0) {
            return res.status(404).json({ message: 'Account not found' });
        }
        res.json({ balance: parseFloat(rows[0].balance), province });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// ==========================================
// GET TRANSACTIONS
// ==========================================
router.get('/accounts/:id/transactions', verifyToken, async (req, res) => {
    const { id } = req.params;
    
    try {
        const metaDB = req.app.get('metaDB');
        const pools = req.app.get('pools');
        
        const province = await getUserProvince(req.userId, metaDB);
        if (!province) return res.status(404).json({ message: 'User not found' });
        
        const pool = pools.get(province);
        const [rows] = await pool.query(
            `SELECT t.id, t.type, t.amount, t.created_at 
             FROM transactions t
             JOIN accounts a ON t.account_id = a.id
             WHERE a.id = ? AND a.user_id = ? 
             ORDER BY t.created_at DESC LIMIT 50`,
            [id, req.userId]
        );
        res.json({ transactions: rows, province });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// ==========================================
// DEPOSIT / WITHDRAW
// ==========================================
router.post('/accounts/:id/transaction', verifyToken, async (req, res) => {
    const { id } = req.params;
    const { amount } = req.body;

    if (typeof amount !== 'number' || amount === 0) {
        return res.status(400).json({ message: 'A valid non-zero amount is required' });
    }

    try {
        const metaDB = req.app.get('metaDB');
        const pools = req.app.get('pools');
        
        const province = await getUserProvince(req.userId, metaDB);
        if (!province) return res.status(404).json({ message: 'User not found' });
        
        const pool = pools.get(province);
        const connection = await pool.getConnection();

        await connection.beginTransaction();

        const [accRows] = await connection.query(
            'SELECT balance FROM accounts WHERE id = ? AND user_id = ? FOR UPDATE',
            [id, req.userId]
        );
        
        if (accRows.length === 0) {
            await connection.rollback();
            connection.release();
            return res.status(404).json({ message: 'Account not found' });
        }

        const currentBalance = Number(accRows[0].balance);
        const type = amount > 0 ? 'deposit' : 'withdraw';
        const absAmount = Math.abs(amount);
        const newBalance = type === 'deposit' ? currentBalance + absAmount : currentBalance - absAmount;

        if (type === 'withdraw' && newBalance < 0) {
            await connection.rollback();
            connection.release();
            return res.status(400).json({ message: 'Insufficient funds' });
        }

        await connection.query('UPDATE accounts SET balance = ? WHERE id = ?', [newBalance, id]);
        await connection.query(
            'INSERT INTO transactions (account_id, type, amount) VALUES (?, ?, ?)',
            [id, type, absAmount]
        );

        await connection.commit();
        connection.release();

        res.json({ 
            message: `${type} successful`, 
            newBalance: parseFloat(newBalance.toFixed(2)),
            transaction: { type, amount: parseFloat(absAmount.toFixed(2)) },
            province 
        });
    } catch (err) {
        if (connection) {
            await connection.rollback();
            connection.release();
        }
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;