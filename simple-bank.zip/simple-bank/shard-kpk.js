// shard-kpk.js - KPK Region Server
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const PORT = 4003; // KPK server port
const DB_NAME = 'bank_kpk';

app.use(cors());
app.use(express.json());

// ========== DATABASE CONNECTION ==========
const db = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'root',
    database: DB_NAME,
    connectionLimit: 10
});

// ========== JWT VERIFICATION ==========
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key';

function verifyToken(req, res, next) {
    const header = req.headers.authorization;
    if (!header) return res.status(401).json({ message: 'Unauthorized' });
    try {
        const payload = jwt.verify(header, JWT_SECRET);
        req.userId = payload.userId;
        next();
    } catch (err) {
        return res.status(401).json({ message: 'Invalid token' });
    }
}

// ========== HEALTH CHECK ==========
app.get('/health', (req, res) => {
    res.json({ status: 'OK', region: 'KPK', port: PORT });
});

// ========== ACCOUNT ROUTES ==========

// Create account in KPK
app.post('/api/shard/account', async (req, res) => {
    const { userId, name, province } = req.body;
    
    try {
        const [result] = await db.query(
            'INSERT INTO accounts (user_id, name, balance, province) VALUES (?, ?, ?, ?)',
            [userId, name, 0.00, province || 'kpk']
        );
        res.json({ 
            accountId: result.insertId, 
            message: 'Account created in KPK shard' 
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get account from KPK
app.get('/api/shard/account', verifyToken, async (req, res) => {
    try {
        const [rows] = await db.query(
            'SELECT * FROM accounts WHERE user_id = ? LIMIT 1', 
            [req.userId]
        );
        res.json({ account: rows[0] || null });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get balance from KPK
app.get('/api/shard/balance', verifyToken, async (req, res) => {
    try {
        const [rows] = await db.query(
            'SELECT balance FROM accounts WHERE user_id = ? LIMIT 1', 
            [req.userId]
        );
        res.json({ balance: rows[0]?.balance || 0 });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get transactions from KPK
app.get('/api/shard/transactions', verifyToken, async (req, res) => {
    try {
        const [rows] = await db.query(
            `SELECT t.* FROM transactions t
             JOIN accounts a ON t.account_id = a.id
             WHERE a.user_id = ? ORDER BY t.created_at DESC LIMIT 50`,
            [req.userId]
        );
        res.json({ transactions: rows });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Transaction in KPK
app.post('/api/shard/transaction', verifyToken, async (req, res) => {
    const { userId, amount } = req.body;
    const connection = await db.getConnection();
    
    try {
        await connection.beginTransaction();
        
        const [accountRows] = await connection.query(
            'SELECT id, balance FROM accounts WHERE user_id = ? LIMIT 1 FOR UPDATE',
            [userId]
        );
        
        if (accountRows.length === 0) {
            await connection.rollback();
            return res.status(404).json({ message: 'Account not found' });
        }
        
        const accountId = accountRows[0].id;
        const currentBalance = parseFloat(accountRows[0].balance);
        const newBalance = parseFloat((currentBalance + amount).toFixed(2));
        
        if (newBalance < 0) {
            await connection.rollback();
            return res.status(400).json({ message: 'Insufficient funds' });
        }
        
        const type = amount > 0 ? 'deposit' : 'withdraw';
        const absAmount = Math.abs(amount);
        
        await connection.query('UPDATE accounts SET balance = ? WHERE id = ?', [newBalance, accountId]);
        await connection.query(
            'INSERT INTO transactions (account_id, type, amount) VALUES (?, ?, ?)',
            [accountId, type, absAmount]
        );
        
        await connection.commit();
        connection.release();
        
        res.json({
            message: 'Transaction successful',
            newBalance,
            transaction: { type, amount: absAmount },
            region: 'KPK'
        });
    } catch (err) {
        await connection.rollback();
        connection.release();
        res.status(500).json({ error: err.message });
    }
});

// Delete account from KPK
app.delete('/api/shard/account', verifyToken, async (req, res) => {
    try {
        await db.query('DELETE FROM accounts WHERE user_id = ?', [req.userId]);
        res.json({ message: 'Account deleted from KPK shard' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ========== START SERVER ==========
app.listen(PORT, () => {
    console.log(`\n🟢 KPK Server Running`);
    console.log(`📍 PORT: ${PORT}`);
    console.log(`🗄️  Database: ${DB_NAME}`);
    console.log(`✅ Region: KPK\n`);
});