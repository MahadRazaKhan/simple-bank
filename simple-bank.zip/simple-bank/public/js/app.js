const API_BASE = '/api';
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const balanceNumber = document.getElementById('balanceNumber');
const plateAccountLabel = document.getElementById('plateAccountLabel');
const transactionContainer = document.getElementById('transactionContainer');
const statusDiv = document.getElementById('statusMessage');
const amountInput = document.getElementById('amountInput');
const ledgerNoEl = document.getElementById('ledgerNo');
const provinceDisplay = document.getElementById('provinceDisplay');
const provinceBadge = document.getElementById('provinceBadge');

let currentBalanceValue = 0;
let accountId = null;
let userProvince = null;

if (ledgerNoEl) {
    ledgerNoEl.textContent = String(Date.now()).slice(-6);
}

function showLoading(message = 'Loading your dashboard...') {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.className = 'active';
        loadingScreen.style.display = 'flex';
        loadingScreen.style.opacity = '1';
        const msgEl = document.getElementById('loadingMessage');
        if (msgEl) msgEl.textContent = message;
    }
}

function hideLoadingScreen() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.style.opacity = '0';
        loadingScreen.className = 'hidden';
        setTimeout(() => {
            loadingScreen.style.display = 'none';
        }, 500);
    }
}

function setStatus(msg, type = 'info') {
    if (!statusDiv) return;
    const glyph = type === 'error' ? '✕' : type === 'success' ? '✓' : '•';
    statusDiv.innerHTML = `<span class="status-glyph">${glyph}</span><span class="status-text">${msg}</span>`;
    statusDiv.className = 'status-bar';
    if (type === 'error') statusDiv.classList.add('error');
    else if (type === 'success') statusDiv.classList.add('success');
    console.log(`📢 Status: ${type} - ${msg}`);
}

function animateBalance(target) {
    if (!balanceNumber) return;
    const start = currentBalanceValue;
    const delta = target - start;
    currentBalanceValue = target;

    if (reduceMotion || Math.abs(delta) < 0.01) {
        balanceNumber.textContent = target.toFixed(2);
        return;
    }

    const duration = 450;
    const startTime = performance.now();

    function tick(now) {
        const elapsed = Math.min((now - startTime) / duration, 1);
        const eased = 1 - Math.pow(1 - elapsed, 3);
        const value = start + delta * eased;
        balanceNumber.textContent = value.toFixed(2);
        if (elapsed < 1) requestAnimationFrame(tick);
        else balanceNumber.textContent = target.toFixed(2);
    }
    requestAnimationFrame(tick);
}

function updateProvinceBadge(province) {
    if (!provinceDisplay || !provinceBadge) return;
    
    userProvince = province;
    const provinceNames = {
        'punjab': 'Punjab',
        'sindh': 'Sindh',
        'kpk': 'KPK',
        'balochistan': 'Balochistan'
    };
    
    provinceDisplay.textContent = provinceNames[province] || province;
    provinceBadge.style.display = 'inline-flex';
    provinceBadge.className = `stack-badge province-${province}`;
    console.log('🏷️ Province updated:', province);
}

function checkAutoLogin() {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    const userId = urlParams.get('userId');
    const username = urlParams.get('username');
    const province = urlParams.get('province');
    
    if (token && userId) {
        console.log('🔄 Auto-login detected!');
        
        sessionStorage.setItem('token', token);
        sessionStorage.setItem('userId', userId);
        sessionStorage.setItem('username', username || 'User');
        if (province) {
            sessionStorage.setItem('province', province);
            updateProvinceBadge(province);
        }
        
        setStatus('✅ Email verified! Welcome to your dashboard!', 'success');
        window.history.replaceState({}, document.title, '/dashboard');
        
        setTimeout(() => {
            hideLoadingScreen();
        }, 2000);
        
        loadAccountData();
        return true;
    }
    return false;
}

async function loadAccountData() {
    console.log('🔄 Loading account data...');
    try {
        const token = sessionStorage.getItem('token');
        console.log('🔑 Token:', token ? 'Present' : 'Missing');
        
        if (!token) {
            console.log('❌ No token, redirecting to login');
            window.location.href = '/login';
            return;
        }

        console.log('📡 Fetching account from:', `${API_BASE}/account`);
        const accountRes = await fetch(`${API_BASE}/account`, {
            headers: {
                'Authorization': token
            }
        });
        
        console.log('📡 Account response status:', accountRes.status);
        
        if (!accountRes.ok) {
            if (accountRes.status === 401) {
                console.log('❌ Unauthorized, redirecting to login');
                forceLogout();
                return;
            }
            throw new Error('Failed to load account');
        }
        
        const accountData = await accountRes.json();
        console.log('📦 Account data:', accountData);
        
        accountId = accountData.account.id;
        console.log('✅ Account ID:', accountId);
        
        if (accountData.account.province) {
            updateProvinceBadge(accountData.account.province);
        }
        
        if (plateAccountLabel) {
            plateAccountLabel.textContent = `${accountData.account.name} — Acct No. ${String(accountData.account.id).padStart(6, '0')}`;
        }

        await loadBalance();
        await loadTransactions();
        
        setStatus('Account loaded successfully', 'success');
    } catch (err) {
        console.error('❌ Error loading account:', err);
        setStatus('Error loading account: ' + err.message, 'error');
    }
}

async function loadBalance() {
    console.log('🔄 Loading balance...');
    try {
        const token = sessionStorage.getItem('token');
        const res = await fetch(`${API_BASE}/account/balance`, {
            headers: {
                'Authorization': token
            }
        });
        
        console.log('📡 Balance response status:', res.status);
        
        if (!res.ok) {
            if (res.status === 401) {
                console.log('❌ Unauthorized, redirecting to login');
                forceLogout();
                return;
            }
            throw new Error('Failed to load balance');
        }
        
        const data = await res.json();
        console.log('💰 Balance data:', data);
        animateBalance(Number(data.balance));
        
        if (data.province) {
            updateProvinceBadge(data.province);
        }
    } catch (err) {
        console.error('❌ Error loading balance:', err);
        setStatus('Error loading balance: ' + err.message, 'error');
    }
}

async function loadTransactions() {
    console.log('🔄 Loading transactions...');
    try {
        const token = sessionStorage.getItem('token');
        const res = await fetch(`${API_BASE}/account/transactions`, {
            headers: {
                'Authorization': token
            }
        });
        
        console.log('📡 Transactions response status:', res.status);
        
        if (!res.ok) {
            if (res.status === 401) {
                console.log('❌ Unauthorized, redirecting to login');
                forceLogout();
                return;
            }
            throw new Error('Failed to load transactions');
        }
        
        const data = await res.json();
        console.log('📋 Transactions data:', data);
        renderTransactions(data.transactions || []);
        
        if (data.province) {
            updateProvinceBadge(data.province);
        }
    } catch (err) {
        console.error('❌ Error loading transactions:', err);
        setStatus('Error loading transactions: ' + err.message, 'error');
    }
}

function renderTransactions(transactions) {
    if (!transactionContainer) return;
    if (!transactions || transactions.length === 0) {
        transactionContainer.innerHTML = '<div class="empty-tx">No entries yet</div>';
        return;
    }
    
    const sorted = [...transactions].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    transactionContainer.innerHTML = sorted.map(tx => {
        const typeClass = tx.type === 'deposit' ? 'deposit' : 'withdraw';
        const sign = tx.type === 'deposit' ? '+' : '−';
        const dateStr = new Date(tx.created_at).toLocaleDateString(undefined, { month: 'short', day: '2-digit' });
        return `<div class="ledger-item ${typeClass}">
            <span class="ledger-dot"></span>
            <span class="ledger-mid">
                <span class="ledger-type">${tx.type}</span>
                <span class="ledger-date">${dateStr}</span>
            </span>
            <span class="ledger-amount">${sign}$${Number(tx.amount).toFixed(2)}</span>
        </div>`;
    }).join('');
}

function forceLogout() {
    console.log('🚪 Force logging out...');
    try {
        sessionStorage.clear();
        localStorage.clear();
        window.location.replace('/login');
    } catch (e) {
        console.error('Logout error:', e);
        window.location.href = '/login';
    }
}

const deleteModalOverlay = document.getElementById('deleteModalOverlay');
const deleteModalCopy = document.getElementById('deleteModalCopy');

function openDeleteModal() {
    console.log('🗑️ Opening delete modal...');
    if (!accountId) {
        setStatus('No account found', 'error');
        return;
    }
    
    if (deleteModalCopy) {
        deleteModalCopy.textContent = `This removes your account and every entry on its ledger. This can't be undone.`;
    }
    if (deleteModalOverlay) {
        deleteModalOverlay.removeAttribute('hidden');
        deleteModalOverlay.style.display = 'flex';
        deleteModalOverlay.style.opacity = '1';
        document.body.classList.add('modal-open');
    }
}

function closeDeleteModal() {
    console.log('❌ Closing delete modal...');
    if (deleteModalOverlay) {
        deleteModalOverlay.setAttribute('hidden', 'hidden');
        deleteModalOverlay.style.display = 'none';
        deleteModalOverlay.style.opacity = '0';
        document.body.classList.remove('modal-open');
    }
}

async function submitDeleteAccount() {
    console.log('🗑️ Submitting delete account...');
    if (!accountId) {
        setStatus('No account found', 'error');
        closeDeleteModal();
        return;
    }
    
    try {
        const token = sessionStorage.getItem('token');
        console.log('📡 DELETE request to:', `${API_BASE}/account`);
        
        const res = await fetch(`${API_BASE}/account`, {
            method: 'DELETE',
            headers: {
                'Authorization': token || ''
            }
        });
        
        console.log('📡 DELETE response status:', res.status);
        const data = await res.json();
        console.log('📦 DELETE response:', data);
        
        closeDeleteModal();
        
        if (!res.ok) {
            if (res.status === 401) {
                forceLogout();
                return;
            }
            setStatus('Delete failed: ' + (data.message || 'Unknown error'), 'error');
            return;
        }
        
        setStatus('Account deleted! Redirecting...', 'success');
        
        console.log('🚪 Clearing session and redirecting...');
        sessionStorage.clear();
        localStorage.clear();
        
        window.location.replace('/login');
        
    } catch (err) {
        console.error('❌ Delete error:', err);
        closeDeleteModal();
        setStatus('Delete error: ' + err.message, 'error');
        
        setTimeout(() => {
            sessionStorage.clear();
            window.location.replace('/login');
        }, 2000);
    }
}

async function performTransaction(type) {
    console.log(`💳 Performing ${type}...`);
    
    if (!accountId) {
        console.log('❌ No account ID');
        setStatus('No account found. Please refresh.', 'error');
        return;
    }
    
    if (!amountInput) {
        console.log('❌ Amount input not found');
        return;
    }
    
    let amount = parseFloat(amountInput.value);
    console.log('💰 Amount:', amount);
    
    if (!amount || amount <= 0) {
        setStatus('Enter a valid positive amount', 'error');
        return;
    }
    
    const finalAmount = type === 'withdraw' ? -Math.abs(amount) : Math.abs(amount);
    console.log(`📊 Final amount: ${finalAmount} (${type})`);

    try {
        const token = sessionStorage.getItem('token');
        console.log('🔑 Token:', token ? 'Present' : 'Missing');
        
        if (!token) {
            setStatus('Please login again', 'error');
            window.location.href = '/login';
            return;
        }
        
        console.log('📡 POST request to:', `${API_BASE}/account/transaction`);
        console.log('📦 Payload:', { amount: finalAmount });
        
        const res = await fetch(`${API_BASE}/account/transaction`, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': token
            },
            body: JSON.stringify({ amount: finalAmount })
        });
        
        console.log('📡 Transaction response status:', res.status);
        const data = await res.json();
        console.log('📦 Transaction response:', data);
        
        if (!res.ok) {
            if (res.status === 401) {
                forceLogout();
                return;
            }
            throw new Error(data.message || 'Transaction failed');
        }
        
        setStatus(`${type === 'deposit' ? 'Deposited' : 'Withdrew'} $${Math.abs(finalAmount).toFixed(2)}`, 'success');
        
        if (data.province) {
            updateProvinceBadge(data.province);
        }
        
        await loadBalance();
        await loadTransactions();
        
    } catch (err) {
        console.error('❌ Transaction error:', err);
        setStatus('Transaction error: ' + err.message, 'error');
    }
}

function logout() {
    console.log('🚪 Logging out...');
    sessionStorage.clear();
    window.location.href = '/login';
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 App loaded - DOM fully ready');
    
    showLoading('Welcome to Simple Bank...');
    
    setTimeout(function() {
        if (checkAutoLogin()) {
            console.log('✅ Auto-login handled');
            return;
        }
        
        const token = sessionStorage.getItem('token');
        console.log('🔑 Token at startup:', token ? 'Present' : 'Missing');
        
        if (!token) {
            console.log('❌ No token, redirecting to login');
            hideLoadingScreen();
            window.location.href = '/login';
            return;
        }
        
        setTimeout(function() {
            hideLoadingScreen();
        }, 3000);
        
        console.log('🔧 Attaching event listeners...');
        
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', logout);
            console.log('✅ Logout button attached');
        }
        
        const deleteAccountBtn = document.getElementById('deleteAccountBtn');
        if (deleteAccountBtn) {
            deleteAccountBtn.addEventListener('click', openDeleteModal);
            console.log('✅ Delete button attached');
        }
        
        const deleteModalCancel = document.getElementById('deleteModalCancel');
        if (deleteModalCancel) {
            deleteModalCancel.addEventListener('click', closeDeleteModal);
            console.log('✅ Delete cancel button attached');
        }
        
        const deleteModalConfirm = document.getElementById('deleteModalConfirm');
        if (deleteModalConfirm) {
            deleteModalConfirm.addEventListener('click', submitDeleteAccount);
            console.log('✅ Delete confirm button attached');
        }
        
        if (deleteModalOverlay) {
            deleteModalOverlay.addEventListener('click', function(e) { 
                if (e.target === this) {
                    closeDeleteModal();
                }
            });
            console.log('✅ Delete overlay click attached');
        }
        
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeDeleteModal();
            }
        });
        console.log('✅ ESC key listener attached');
        
        const depositWithAmountBtn = document.getElementById('depositWithAmountBtn');
        if (depositWithAmountBtn) {
            depositWithAmountBtn.addEventListener('click', function() {
                console.log('💰 Deposit with amount button clicked!');
                performTransaction('deposit');
            });
            console.log('✅ Deposit with amount button attached');
        }
        
        const withdrawWithAmountBtn = document.getElementById('withdrawWithAmountBtn');
        if (withdrawWithAmountBtn) {
            withdrawWithAmountBtn.addEventListener('click', function() {
                console.log('💸 Withdraw with amount button clicked!');
                performTransaction('withdraw');
            });
            console.log('✅ Withdraw with amount button attached');
        }
        
        const depositBtn = document.getElementById('depositBtn');
        if (depositBtn) {
            depositBtn.addEventListener('click', function() {
                console.log('💰 Deposit button clicked!');
                performTransaction('deposit');
            });
            console.log('✅ Deposit button attached');
        }
        
        const withdrawBtn = document.getElementById('withdrawBtn');
        if (withdrawBtn) {
            withdrawBtn.addEventListener('click', function() {
                console.log('💸 Withdraw button clicked!');
                performTransaction('withdraw');
            });
            console.log('✅ Withdraw button attached');
        }
        
        const refreshBtn = document.getElementById('refreshBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', loadAccountData);
            console.log('✅ Refresh button attached');
        }
        
        const refreshTransactionsBtn = document.getElementById('refreshTransactionsBtn');
        if (refreshTransactionsBtn) {
            refreshTransactionsBtn.addEventListener('click', async function() {
                await loadTransactions();
                setStatus('Transactions refreshed', 'success');
            });
            console.log('✅ Refresh transactions button attached');
        }
        
        console.log('📡 Loading initial data...');
        loadAccountData();
        
        console.log('✅ All event listeners attached successfully!');
    }, 500);
});