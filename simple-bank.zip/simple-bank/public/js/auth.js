const API_BASE = '/api';

// ==========================================
// LOADING SCREEN FUNCTIONS
// ==========================================
function showLoading(message = 'Loading your dashboard...') {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.className = 'active';
        loadingScreen.style.display = 'flex';
        loadingScreen.style.opacity = '1';
        const msgEl = document.getElementById('loadingMessage');
        if (msgEl) msgEl.textContent = message;
    }
}

function hideLoading() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.style.opacity = '0';
        loadingScreen.className = 'hidden';
        setTimeout(() => {
            loadingScreen.style.display = 'none';
        }, 500);
    }
}

// ==========================================
// MAIN AUTH LOGIC
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    // Check if already logged in (sessionStorage)
    if (sessionStorage.getItem('token')) {
        showLoading('Welcome back!');
        setTimeout(() => {
            window.location.href = '/dashboard';
        }, 1500); // ✅ 300 se 1500 kar diya (1.5 sec)
        return;
    }

    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const loginBtn = document.getElementById('loginBtn');
    const signupBtn = document.getElementById('signupBtn');
    const loginStatus = document.getElementById('loginStatus');
    const signupStatus = document.getElementById('signupStatus');
    const tabs = document.querySelectorAll('.auth-tab');
    const emailField = document.getElementById('emailField');
    const loginEmail = document.getElementById('loginEmail');

    // ✅ Check verification status from URL
    const urlParams = new URLSearchParams(window.location.search);
    const verified = urlParams.get('verified');

    if (verified === 'true') {
        loginStatus.className = 'auth-status show success';
        loginStatus.textContent = '✅ Email verified successfully! You can now login.';
    } else if (verified === 'already') {
        loginStatus.className = 'auth-status show info';
        loginStatus.textContent = 'ℹ️ Your email is already verified. Please login.';
    } else if (verified === 'invalid' || verified === 'expired') {
        loginStatus.className = 'auth-status show error';
        loginStatus.textContent = '❌ Invalid or expired verification link. Please try again.';
    } else if (verified === 'error') {
        loginStatus.className = 'auth-status show error';
        loginStatus.textContent = '❌ Something went wrong. Please try again.';
    }

    // Tabs
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            if (this.dataset.tab === 'login') {
                loginForm.classList.remove('hidden');
                signupForm.classList.add('hidden');
                loginStatus.className = 'auth-status';
                loginStatus.textContent = '';
                if (emailField) emailField.style.display = 'none';
            } else {
                loginForm.classList.add('hidden');
                signupForm.classList.remove('hidden');
                signupStatus.className = 'auth-status';
                signupStatus.textContent = '';
            }
        });
    });

    // Toggle password visibility
    document.querySelectorAll('.password-toggle').forEach(btn => {
        btn.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                input.type = 'password';
                icon.className = 'fas fa-eye';
            }
        });
    });

    // ==========================================
    // LOGIN
    // ==========================================
    loginBtn.addEventListener('click', async function() {
        const username = document.getElementById('loginUsername').value.trim();
        const password = document.getElementById('loginPassword').value.trim();
        
        if (!username || !password) {
            loginStatus.className = 'auth-status show error';
            loginStatus.textContent = 'Please enter username and password';
            return;
        }
        
        // ✅ Show loading
        showLoading('Logging you in...');
        
        try {
            const res = await fetch(`${API_BASE}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            
            const data = await res.json();
            
            if (!res.ok) {
                hideLoading();
                
                // ✅ Check if verification required
                if (res.status === 403 && data.requiresVerification) {
                    if (emailField) emailField.style.display = 'block';
                    
                    loginStatus.className = 'auth-status show error';
                    loginStatus.innerHTML = `
                        ⚠️ Please verify your email first. Check your inbox!
                        <br><br>
                        <div style="display: flex; flex-direction: column; gap: 8px;">
                            <input type="email" id="resendEmailInput" placeholder="Enter your registered email" 
                                   style="padding: 8px 12px; border-radius: 4px; border: 1px solid rgba(237,238,242,0.14); 
                                          background: var(--surface-2); color: var(--ink); width: 100%;">
                            <button id="resendVerificationBtn" style="background: var(--gold); color: #1a1406; 
                                    border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-weight: 600;">
                                🔄 Resend Verification Email
                            </button>
                        </div>
                    `;
                    
                    document.getElementById('resendVerificationBtn')?.addEventListener('click', async function() {
                        const emailInput = document.getElementById('resendEmailInput');
                        const email = emailInput?.value.trim();
                        
                        if (!email || !email.includes('@') || !email.includes('.')) {
                            loginStatus.className = 'auth-status show error';
                            loginStatus.innerHTML = '⚠️ Please enter a valid email address.';
                            return;
                        }
                        
                        try {
                            const res = await fetch(`${API_BASE}/auth/resend-verification`, {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ email })
                            });
                            const data = await res.json();
                            if (!res.ok) throw new Error(data.message);
                            
                            loginStatus.className = 'auth-status show success';
                            loginStatus.innerHTML = `✅ Verification email resent to <strong>${email}</strong>! Check your inbox.`;
                            
                            if (emailInput) emailInput.value = '';
                            if (emailField) emailField.style.display = 'none';
                        } catch (err) {
                            loginStatus.className = 'auth-status show error';
                            loginStatus.innerHTML = '❌ ' + err.message;
                        }
                    });
                    return;
                }
                
                loginStatus.className = 'auth-status show error';
                loginStatus.textContent = data.message || 'Login failed';
                return;
            }
            
            // ✅ Use sessionStorage
            sessionStorage.setItem('token', data.token);
            sessionStorage.setItem('userId', data.user.id);
            sessionStorage.setItem('username', data.user.username);
            if (data.user.province) {
                sessionStorage.setItem('province', data.user.province);
            }
            
            loginStatus.className = 'auth-status show success';
            loginStatus.textContent = 'Login successful! Redirecting...';
            
            // ✅ 800 se 3000 kar diya (3 sec loading)
            setTimeout(() => {
                window.location.href = '/dashboard';
            }, 3000);
            
        } catch (err) {
            hideLoading();
            loginStatus.className = 'auth-status show error';
            loginStatus.textContent = 'Network error. Please try again.';
        }
    });

    // ==========================================
    // SIGNUP
    // ==========================================
    signupBtn.addEventListener('click', async function() {
        const username = document.getElementById('signupUsername').value.trim();
        const email = document.getElementById('signupEmail').value.trim();
        const password = document.getElementById('signupPassword').value;
        const confirm = document.getElementById('signupConfirmPassword').value;
        const province = document.getElementById('signupProvince').value;
        
        // Validation
        if (!username || !email || !password || !confirm || !province) {
            signupStatus.className = 'auth-status show error';
            signupStatus.textContent = 'Please fill in all fields including province';
            return;
        }
        
        if (username.length < 3) {
            signupStatus.className = 'auth-status show error';
            signupStatus.textContent = 'Username must be at least 3 characters';
            return;
        }
        
        if (!email.includes('@') || !email.includes('.')) {
            signupStatus.className = 'auth-status show error';
            signupStatus.textContent = 'Please enter a valid email address';
            return;
        }
        
        if (password.length < 8) {
            signupStatus.className = 'auth-status show error';
            signupStatus.textContent = 'Password must be at least 8 characters';
            return;
        }
        
        if (password !== confirm) {
            signupStatus.className = 'auth-status show error';
            signupStatus.textContent = 'Passwords do not match';
            return;
        }
        
        // ✅ Show loading
        showLoading('Creating your account...');
        
        try {
            const res = await fetch(`${API_BASE}/auth/signup`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, email, password, province })
            });
            
            const data = await res.json();
            
            if (!res.ok) {
                hideLoading();
                signupStatus.className = 'auth-status show error';
                signupStatus.textContent = data.message || 'Signup failed';
                return;
            }
            
            signupStatus.className = 'auth-status show success';
            signupStatus.textContent = `✅ Account created! Please check your email (${email}) to confirm.`;
            
            // Clear form
            document.getElementById('signupUsername').value = '';
            document.getElementById('signupEmail').value = '';
            document.getElementById('signupPassword').value = '';
            document.getElementById('signupConfirmPassword').value = '';
            document.getElementById('signupProvince').value = '';
            
            // ✅ 10 se 4000 kar diya (4 sec loading)
            setTimeout(() => {
                hideLoading();
                document.querySelector('[data-tab="login"]').click();
                loginStatus.className = 'auth-status show info';
                loginStatus.textContent = `📧 We've sent a confirmation email to ${email}. Please check your inbox!`;
                if (emailField) emailField.style.display = 'none';
            }, 4000);
            
        } catch (err) {
            hideLoading();
            signupStatus.className = 'auth-status show error';
            signupStatus.textContent = 'Network error. Please try again.';
        }
    });

    // Enter key support
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            if (!loginForm.classList.contains('hidden')) {
                loginBtn.click();
            } else if (!signupForm.classList.contains('hidden')) {
                signupBtn.click();
            }
        }
    });
});