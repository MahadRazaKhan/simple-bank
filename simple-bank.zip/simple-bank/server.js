const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key';

const pools = {
    punjab: mysql.createPool({
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || 'root',
        database: process.env.DB_PUNJAB || 'bank_punjab',
        connectionLimit: 10
    }),
    sindh: mysql.createPool({
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || 'root',
        database: process.env.DB_SINDH || 'bank_sindh',
        connectionLimit: 10
    }),
    kpk: mysql.createPool({
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || 'root',
        database: process.env.DB_KPK || 'bank_kpk',
        connectionLimit: 10
    }),
    balochistan: mysql.createPool({
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || 'root',
        database: process.env.DB_BALOCHISTAN || 'bank_balochistan',
        connectionLimit: 10
    })
};

const metaDB = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'root',
    database: process.env.DB_METADATA || 'bank_metadata',
    connectionLimit: 10
});

const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.EMAIL_PORT) || 587,
    secure: false,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    },
    tls: {
        rejectUnauthorized: false
    }
});

transporter.verify((error) => {
    if (error) console.log('Email configuration error:', error.message);
    else console.log('Email server ready');
});

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const asyncHandler = fn => (req, res, next) => fn(req, res, next).catch(next);

const PROVINCES = ['punjab', 'sindh', 'kpk', 'balochistan'];

function isValidProvince(p) {
    return typeof p === 'string' && PROVINCES.includes(p);
}

function issueToken(userId) {
    return jwt.sign({ userId }, JWT_SECRET, { expiresIn: '7d' });
}

function verifyToken(req, res, next) {
    const header = req.headers.authorization;
    if (!header) return res.status(401).json({ message: 'Unauthorized' });
    try {
        const payload = jwt.verify(header, JWT_SECRET);
        req.userId = payload.userId;
        next();
    } catch (err) {
        return res.status(401).json({ message: 'Invalid or expired token' });
    }
}

function issueVerificationToken(userId) {
    return jwt.sign({ userId, purpose: 'verify-email' }, JWT_SECRET, { expiresIn: '24h' });
}

function readVerificationToken(token) {
    const payload = jwt.verify(token, JWT_SECRET);
    if (payload.purpose !== 'verify-email') throw new Error('Wrong token type');
    return payload;
}

async function getUserProvince(userId) {
    const [rows] = await metaDB.query('SELECT province FROM users WHERE id = ?', [userId]);
    if (rows.length === 0) return null;
    return rows[0].province;
}

async function sendConfirmationEmail(email, username, userId) {
    const token = issueVerificationToken(userId);
    const confirmLink = `http://localhost:${PORT}/api/verify?token=${encodeURIComponent(token)}`;

    const mailOptions = {
        from: process.env.EMAIL_FROM || 'noreply@simplebank.com',
        to: email,
        subject: 'Welcome to Simple Bank - Confirm Your Email',
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #0a0f1c; color: #ece9e0; border-radius: 10px;">
                <h1 style="color: #c9a227;">Simple Bank</h1>
                <h2>Welcome, ${username}!</h2>
                <p>Thank you for choosing Simple Bank.</p>
                <p>Please confirm your email by clicking the button below:</p>
                <a href="${confirmLink}" style="display: inline-block; padding: 12px 30px; background: #c9a227; color: #1a1406; text-decoration: none; border-radius: 6px; font-weight: 600; margin: 20px 0;">Confirm Email</a>
                <p style="color: #8590a6; font-size: 0.8rem;">If you didn't create this account, please ignore this email.</p>
                <hr style="border-color: rgba(237, 238, 242, 0.08);">
                <p style="color: #5b6478; font-size: 0.7rem;">Simple Bank · Secure · Encrypted</p>
            </div>
        `,
        text: `Welcome to Simple Bank, ${username}!\n\nConfirm your email: ${confirmLink}\n\nIf you didn't create this account, please ignore this email.`
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log(`Confirmation email sent to ${email}`);
        return true;
    } catch (error) {
        console.error('Email send error:', error.message);
        return false;
    }
}

app.post('/api/auth/login', asyncHandler(async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ message: 'Username and password required' });
    }

    const [rows] = await metaDB.query('SELECT * FROM users WHERE username = ?', [username]);
    if (rows.length === 0) return res.status(401).json({ message: 'Invalid credentials' });

    const user = rows[0];
    const passwordOk = await bcrypt.compare(password, user.password);
    if (!passwordOk) return res.status(401).json({ message: 'Invalid credentials' });

    if (!user.is_verified) {
        return res.status(403).json({
            message: 'Please verify your email first. Check your inbox!',
            requiresVerification: true
        });
    }

    const token = issueToken(user.id);
    res.json({
        message: 'Login successful',
        token,
        user: {
            id: user.id,
            username: user.username,
            email: user.email,
            province: user.province,
            isVerified: !!user.is_verified
        }
    });
}));

app.post('/api/auth/signup', asyncHandler(async (req, res) => {
    const { username, email, password, province } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ message: 'Username, email and password are required' });
    }
    if (!isValidProvince(province)) {
        return res.status(400).json({ message: 'Please select a valid province' });
    }
    if (password.length < 8) {
        return res.status(400).json({ message: 'Password must be at least 8 characters' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const pool = pools[province];

    let userId;
    try {
        const [result] = await metaDB.query(
            'INSERT INTO users (username, email, password, province, is_verified) VALUES (?, ?, ?, ?, ?)',
            [username, email, passwordHash, province, false]
        );
        userId = result.insertId;
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ message: 'Username or email already exists' });
        }
        throw err;
    }

    let accountId;
    try {
        const [accountResult] = await pool.query(
            'INSERT INTO accounts (user_id, name, balance, province) VALUES (?, ?, ?, ?)',
            [userId, 'Main Account', 0.00, province]
        );
        accountId = accountResult.insertId;
    } catch (err) {
        await metaDB.query('DELETE FROM users WHERE id = ?', [userId]).catch(() => {});
        return res.status(500).json({ message: 'Failed to create account in shard' });
    }

    try {
        await metaDB.query(
            'INSERT INTO account_routes (account_id, province) VALUES (?, ?)',
            [accountId, province]
        );
    } catch (err) {
        await pool.query('DELETE FROM accounts WHERE id = ?', [accountId]).catch(() => {});
        await metaDB.query('DELETE FROM users WHERE id = ?', [userId]).catch(() => {});
        return res.status(500).json({ message: 'Failed to save route info' });
    }

    await sendConfirmationEmail(email, username, userId);

    res.status(201).json({
        message: `Account created successfully in ${province}! Please check your email to confirm.`,
        user: { id: userId, username, email, province },
        account: { id: accountId, name: 'Main Account', balance: 0, province }
    });
}));

app.get('/api/verify', asyncHandler(async (req, res) => {
    const { token } = req.query;
    if (!token) return res.redirect('/login?verified=invalid');

    let payload;
    try {
        payload = readVerificationToken(token);
    } catch (err) {
        return res.redirect('/login?verified=expired');
    }

    const [result] = await metaDB.query('UPDATE users SET is_verified = true WHERE id = ?', [payload.userId]);
    if (result.affectedRows === 0) return res.redirect('/login?verified=error');

    const [rows] = await metaDB.query('SELECT id, username, province FROM users WHERE id = ?', [payload.userId]);
    if (rows.length === 0) return res.redirect('/login?verified=error');

    const user = rows[0];
    const loginToken = issueToken(user.id);
    res.redirect(`/dashboard?token=${encodeURIComponent(loginToken)}&userId=${user.id}&username=${encodeURIComponent(user.username)}&province=${user.province}`);
}));

app.post('/api/auth/resend-verification', asyncHandler(async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ message: 'Email is required' });

    const [rows] = await metaDB.query('SELECT id, username FROM users WHERE email = ? AND is_verified = false', [email]);
    if (rows.length === 0) {
        return res.status(404).json({ message: 'User not found or already verified' });
    }

    const user = rows[0];
    await sendConfirmationEmail(email, user.username, user.id);
    res.json({ message: 'Verification email resent successfully!' });
}));

app.get('/api/account', verifyToken, asyncHandler(async (req, res) => {
    const province = await getUserProvince(req.userId);
    if (!province) return res.status(404).json({ message: 'User not found' });

    const pool = pools[province];
    const [rows] = await pool.query('SELECT * FROM accounts WHERE user_id = ? LIMIT 1', [req.userId]);
    res.json({ account: rows[0] || null, province });
}));

app.get('/api/account/balance', verifyToken, asyncHandler(async (req, res) => {
    const province = await getUserProvince(req.userId);
    if (!province) return res.status(404).json({ message: 'User not found' });

    const pool = pools[province];
    const [rows] = await pool.query('SELECT balance FROM accounts WHERE user_id = ? LIMIT 1', [req.userId]);
    res.json({ balance: rows[0]?.balance || 0, province });
}));

app.get('/api/account/transactions', verifyToken, asyncHandler(async (req, res) => {
    const province = await getUserProvince(req.userId);
    if (!province) return res.status(404).json({ message: 'User not found' });

    const pool = pools[province];
    const [rows] = await pool.query(
        `SELECT t.* FROM transactions t JOIN accounts a ON t.account_id = a.id WHERE a.user_id = ? ORDER BY t.created_at DESC LIMIT 50`,
        [req.userId]
    );
    res.json({ transactions: rows, province });
}));

app.post('/api/account/transaction', verifyToken, asyncHandler(async (req, res) => {
    const { amount } = req.body;
    if (typeof amount !== 'number' || amount === 0) {
        return res.status(400).json({ message: 'Valid amount required' });
    }

    const province = await getUserProvince(req.userId);
    if (!province) return res.status(404).json({ message: 'User not found' });

    const pool = pools[province];
    const connection = await pool.getConnection();

    try {
        await connection.beginTransaction();

        const [accountRows] = await connection.query(
            'SELECT id, balance FROM accounts WHERE user_id = ? LIMIT 1 FOR UPDATE',
            [req.userId]
        );
        if (accountRows.length === 0) {
            await connection.rollback();
            connection.release();
            return res.status(404).json({ message: 'Account not found' });
        }

        const accountId = accountRows[0].id;
        const currentBalance = parseFloat(accountRows[0].balance);
        const newBalance = parseFloat((currentBalance + amount).toFixed(2));

        if (newBalance < 0) {
            await connection.rollback();
            connection.release();
            return res.status(400).json({ message: 'Insufficient funds' });
        }

        const type = amount > 0 ? 'deposit' : 'withdraw';
        const absAmount = Math.abs(amount);

        await connection.query('UPDATE accounts SET balance = ? WHERE id = ?', [newBalance, accountId]);
        await connection.query(
            'INSERT INTO transactions (account_id, type, amount) VALUES (?, ?, ?)',
            [accountId, type, absAmount]
        );
        await connection.commit();
        connection.release();

        res.json({
            message: 'Transaction successful',
            newBalance,
            transaction: { type, amount: absAmount },
            province
        });
    } catch (err) {
        await connection.rollback();
        connection.release();
        throw err;
    }
}));

app.delete('/api/account', verifyToken, asyncHandler(async (req, res) => {
    console.log('Delete request for user:', req.userId);
    
    const province = await getUserProvince(req.userId);
    if (!province) {
        return res.status(404).json({ message: 'User not found' });
    }

    const pool = pools[province];
    
    const [accountRows] = await pool.query('SELECT id FROM accounts WHERE user_id = ?', [req.userId]);
    const accountId = accountRows[0]?.id;

    await pool.query('DELETE FROM accounts WHERE user_id = ?', [req.userId]);
    console.log('Account deleted from shard:', province);

    if (accountId) {
        await metaDB.query('DELETE FROM account_routes WHERE account_id = ?', [accountId]);
    }
    await metaDB.query('DELETE FROM users WHERE id = ?', [req.userId]);
    console.log('User deleted from metadata:', req.userId);

    res.json({ 
        message: 'Account deleted successfully',
        redirect: '/login'
    });
}));

app.get('/api/health', asyncHandler(async (req, res) => {
    const status = { main: 'OK', shards: {} };
    let allConnected = true;

    for (const [name, pool] of Object.entries(pools)) {
        try {
            await pool.query('SELECT 1');
            status.shards[name] = 'connected';
        } catch {
            status.shards[name] = 'disconnected';
            allConnected = false;
        }
    }

    try {
        await metaDB.query('SELECT 1');
        status.metadata = 'connected';
    } catch {
        status.metadata = 'disconnected';
        allConnected = false;
    }

    res.status(allConnected ? 200 : 503).json(status);
}));

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({ message: 'Something went wrong' });
});

app.listen(PORT, () => {
    console.log(`\nServer running on http://localhost:${PORT}`);
});